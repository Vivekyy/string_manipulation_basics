import java.util.List;

public class SpellTester{
    
    public static void main(String[] args){
        
        SpellChecker checker = new SpellChecker("words.txt");
        
        System.out.println();
        System.out.println("Incorrect words:");
        
        List<String> incorrectWords = checker.getIncorrectWords("test.txt");
        System.out.println(incorrectWords);
        System.out.println();
        
        for(String element : incorrectWords){
            System.out.println("Suggestions for " + element + ":");
            System.out.println(checker.getSuggestions(element));
            System.out.println();
        }
        
    }
    
}