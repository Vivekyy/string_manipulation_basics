public class KTester{
    
    public static void main(String[] args){
        
        KBestCounter<Integer> tester = new KBestCounter(5);
        
        Integer [] testset1 = {3, 5, 6, 12, 4, 78, 9, 11, 3, 10, 78};
        
        for(Integer number : testset1){
            tester.count(number);
        }
        
        System.out.println();
        System.out.println("Test 1:[10, 11, 12, 78, 78]");
        System.out.println(tester.kbest());
        
        KBestCounter<Integer> tester2 = new KBestCounter(3);
        
        Integer [] testset2 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        
        for(Integer number : testset2){
            tester2.count(number);
        }
        
        System.out.println();
        System.out.println("Test 2: [8, 9, 10]");
        System.out.println(tester2.kbest());
        System.out.println("Go again");
        System.out.println(tester2.kbest());
        
        tester2.count(11);
        System.out.println();
        System.out.println("Test 3: [9, 10, 11]");
        System.out.println(tester2.kbest());
        
    }
    
}