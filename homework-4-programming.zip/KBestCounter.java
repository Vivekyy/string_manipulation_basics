import java.util.*;

public class KBestCounter<T extends Comparable<? super T>> implements KBest<T>{
    
    public final int k;
    private PriorityQueue<T> queue;
    
    public KBestCounter(int k){
        this.k = k;
        queue = new PriorityQueue();
    }
    
    public void count(T x){
        
        if(queue.size()<k){
            queue.add(x); //O(logk)
        }
        else if(x.compareTo(queue.peek())>0){
            queue.poll(); //O(1)
            queue.add(x); //O(logk)
        }
        else{ //If new element smaller than all elements in the queue, don't do anything
            ;
        }

    }
    
	public List<T> kbest(){
        
        ArrayList<T> output = new ArrayList();
        
        Iterator iterator = queue.iterator();
        while(iterator.hasNext()){ //O(k)
            output.add((T) iterator.next()); //Cast back to T since iterator returns Object
        }
        
        Collections.sort(output); //O(klogk) since Java uses MergeSort
        return output;
    }
    
}