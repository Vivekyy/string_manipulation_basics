import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

public class SpellChecker implements SpellCheckerInterface{
    
    HashSet<String> dictionary;
    
    public SpellChecker(String dictFileName){
        
        dictionary = new HashSet();
        String temp;
        
        try{
            Scanner dictReader = new Scanner(new File(dictFileName));
            while(dictReader.hasNextLine()){
                temp = dictReader.nextLine();
                //I believe removing punctuation from the dictionary is necessary, though it wasn't specified in the instructions
                temp = removePunctuation(temp.toLowerCase()); 
                dictionary.add(temp);
            }
        }
        catch(FileNotFoundException e){
            System.out.println("The dictionary file specified does not exist");
        }

    }
    
    public List<String> getIncorrectWords(String filename){
        
        List<String> output = new ArrayList();
        Scanner fileScan;
        
        try{
            fileScan = new Scanner(new File(filename));
        }
        catch(FileNotFoundException e){
            System.out.println("Your input file could not be found");
            return output;
        }
        
        String[] currentLine;
        String lineString;
        while(fileScan.hasNextLine()){
            
            lineString = fileScan.nextLine();
            
            if(!lineString.isEmpty()){
                
                currentLine = lineString.split(" ");
                
                String temp;
                for(String word: currentLine){
                    temp = word.toLowerCase();
                    temp = removePunctuation(temp);
                    if(!dictionary.contains(temp)){
                        output.add(temp);
                    }
                }
                
            }
        }
        
        return output;
    }
    
	public Set<String> getSuggestions(String word){
        
        Set<String> suggestions = new HashSet();
        suggestions = tryAdd(suggestions, word);
        suggestions = tryRemove(suggestions, word);
        suggestions = trySwap(suggestions, word);
        
        return suggestions;
        
    }
    
    private Set<String> tryAdd(Set<String> suggestions, String word){
        
        Set<String> newSuggestions = suggestions;
        
        char temp;
        String trial;
        StringBuilder wordChanger;
        for(temp = 'a'; temp<='z'; ++temp){
            for(int i=0; i<word.length(); i++){
                wordChanger = new StringBuilder(word);
                trial = wordChanger.insert(i, temp).toString();
                if(dictionary.contains(trial)){
                    newSuggestions.add(trial);
                }
            }
            //For adding a letter to the end of the word (the above loop only adds within the string)
            trial = word + temp;
            if(dictionary.contains(trial)){
                newSuggestions.add(trial);
            }
        }
        
        return newSuggestions;
        
    }
    
    private Set<String> tryRemove(Set<String> suggestions, String word){
        
        Set<String> newSuggestions = suggestions;
        
        String trial;
        StringBuilder wordChanger;
        for(int i=0; i<word.length(); i++){
            wordChanger = new StringBuilder(word);
            trial = wordChanger.deleteCharAt(i).toString();
            if(dictionary.contains(trial)){
                newSuggestions.add(trial);
            }
        }
        
        return newSuggestions;
    }
    
    private Set<String> trySwap(Set<String> suggestions, String word){
        
        Set<String> newSuggestions = suggestions;
        
        char previous;
        String trial;
        StringBuilder wordChanger;
        for(int i=1; i<word.length(); i++){
            
            wordChanger = new StringBuilder(word);
            previous = word.charAt(i-1);
            wordChanger.setCharAt(i-1, word.charAt(i));
            wordChanger.setCharAt(i, previous);
            trial = wordChanger.toString();
            
            if(dictionary.contains(trial)){
                newSuggestions.add(trial);
            }
        }
        
        return newSuggestions;
    }
    
    private String removePunctuation(String input){
        
        //Just learned that I could have done this much easier :(
        
        String output=input;
        
        output = output.replace(",", "");
        output = output.replace(".", "");
        output = output.replace("<", "");
        output = output.replace(">", "");
        output = output.replace("/", "");
        output = output.replace("?", "");
        output = output.replace(";", "");
        output = output.replace(":", "");
        output = output.replace("'", "");
        output = output.replace("\"", "");
        output = output.replace("\\", "");
        output = output.replace("|", "");
        output = output.replace("[", "");
        output = output.replace("]", "");
        output = output.replace("{", "");
        output = output.replace("}", "");
        output = output.replace("=", "");
        output = output.replace("+", "");
        output = output.replace("-", "");
        output = output.replace("_", "");
        output = output.replace("(", "");
        output = output.replace(")", "");
        output = output.replace("*", "");
        output = output.replace("&", "");
        output = output.replace("^", "");
        output = output.replace("%", "");
        output = output.replace("$", "");
        output = output.replace("#", "");
        output = output.replace("@", "");
        output = output.replace("!", "");
        output = output.replace("~", "");
        output = output.replace("`", "");
        
        return output;
        
    }
    
}